package retail.core;

public enum UserType {
	EMPLOYEE,
	AFFILIATE,
	SIMPLE
}
