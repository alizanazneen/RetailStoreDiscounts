package retail.core;

/*
 * The category of product/item
 * 
 */
public enum ItemType {
	GROCERY,
	OTHER,
}
